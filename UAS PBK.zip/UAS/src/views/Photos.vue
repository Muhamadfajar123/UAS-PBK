<template>
    <PhotoList />
  </template>
  
  <script setup>
  import PhotoList from '../components/PhotoList.vue';
  </script>
  