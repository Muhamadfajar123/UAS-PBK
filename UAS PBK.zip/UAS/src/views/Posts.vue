<template>
    <PostList />
  </template>
  
  <script setup>
  import PostList from '../components/PostList.vue';
  </script>
  