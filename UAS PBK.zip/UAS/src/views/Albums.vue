<template>
    <AlbumList />
  </template>
  
  <script setup>
  import AlbumList from '../components/AlbumList.vue';
  </script>
  